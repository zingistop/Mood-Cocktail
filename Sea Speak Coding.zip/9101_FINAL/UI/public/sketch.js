/*
Notice: Please use Chrome on phone to run UI !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!  (Safari or others may not work as expect)
Notice: Only English please
Notice: There are some bias we forgot to consider, if you didn't write
emotion words existing in AFINN-165, you can't see wine images in the last page
You can type sth like: " I feel so happy today. I love your bar" and expereience this
*/




//Code Referencing and Credit: (Luke,2022), the codes here are from IDEA9101 LAB
document.addEventListener('touchstart', function(e) {
  document.documentElement.style.overflow = 'hidden';
});

document.addEventListener('touchend', function(e) {
  document.documentElement.style.overflow = 'auto';
});


/*
Code Referencing and Credit: (ChatGPT,2023)
"barMoodAdverbs" and "barMoodConjunctions" are word arrays 
we created for the SA model to address biases and better detect 
the semantic meaning of users. These phrases were derived from user testing 
of our simplified music bar scenario simulation and ChatGPT's 
generated responses.

Here barMoodNegatives didn't write words like doesn't, 
don't, the reason is because there is no time left and it needs more process
*/
let barMoodAdverbs = [
  "absolutely","amazingly","astonishingly","awfully","completely",
  "deeply","enormously","especially","exceptionally","extraordinarily",
  "extremely","fairly","fantastically","fully","greatly",
  "highly","hugely","immensely","incredibly","intensely",
  "particularly","perfectly","positively","pretty","profoundly",
  "quite","rather","really","remarkably","seriously",
  "significantly","so","super","totally","truly",
  "unusually","utterly","very","wonderfully","madly",
  "wildly","insanely","crazily","ridiculously","freakishly",
  "hysterically","dramatically","outrageously","excessively","hellishly",
  "majorly","unbelievably","staggeringly","mind-blowingly","blindingly",
  "breathtakingly","sickeningly","alarmingly","soberingly","drunkenly",
  "tipsily","buzzingly","booze-fueled","liquor-lubricated","beer-soaked"
];

let barMoodConjunctions = [
  "however", "but", "yet", "although", "though", 'tho',
  "nevertheless", "nonetheless", "still", "despite", "in contrast",
   "on the other hand", "conversely", "whereas", "instead", "in spite of", 
   "conversely", "on the contrary", "nonetheless", "regardless", "even so"];

let barMoodNegatives = ["never","no","not","neither"];

/*
Varaibles (Luke,2022)
*/
let MAX_NUM_MESSAGES = 20;
let allMessages = new Array();


/*
Code Referencing and Credit: (Luke,2022), 
Varaibles revelent to Client-Server Communication
*/
var HOST = window.location.origin;
var socket;
let xmlHttpRequest = new XMLHttpRequest();

/*
Varaibles revelent to User interfaces
*/
let currentPage = 0;
let isAdOver = false;
let ads_background;
let ads_robot;
let ads_music;
let page_0_img;
let page_1_robot;
let page_2_img;
let circle;
let page_1_buttonA;
let page_1_buttonB;
let bullet_input;
let page_2_button;
let sa_input;
let page_3_button;
let page_3_wave;
let page_4_light;


//Varaibles revelent to Sentiment Analysis
let wordsArray = []; // 用于存储拆分后的单词
let scoredwords;
let total_score;
let averageScore;


//Varaibles revelent to Wine page
let wine_poor = [];
let wine_poor_name = ['Manhattan','Gin_Tonic','Absinthe'];
let wine_poor_desc = [
'Combine dry and sweet vermouth to make the perfect Manhattan cocktail. Drink it and let everything sad go with the wind!',
'Classic and easy, the gin and tonic is light and refreshing. It is a simple mixed drink that requires just the two named ingredients and a hint of lime. Drink it and start afresh!',
'With rum, coconut milk and pineapple juice as the main ingredients, add ice to mix and stir, taste rich and sweet. You can have a wonderful time!'];
let wine_fair = [];
let wine_fair_name = ['Bloody_Mary','Tequila','Dry_Martini'];
let wine_fair_desc = [
'It is one of the world best known cocktails, prized for its ability to cheer you up. With the addition of heat sources, the overall flavor is savory and spicy.',
'Tequila is smooth, sweet, and fruity. Its unique mild spicy taste can release you!',
'A chilled gin martini served up in a graceful cocktail glass is one of the most elegant and sophisticated drinks around. Spicy taste, high degree of wine, have the effect of refreshing!'];
let wine_average = [];
let wine_average_name = ['Screwdriver','Michelada','Margarita'];
let wine_average_desc = [
'Mix freshly squeezed orange juice with vodka and Angostura bitters for a classic screwdriver cocktail. Bring the taste of summer holidays to your smooth life!',
'Cold lager, chilli powder, pepper and lime – spice up your lager with this Mexican cocktail, great for a summer party!',
'Cool off this summer with our simple frozen margarita recipe. This refreshing tequila cocktail can make you feel good and comfortable!'];
let wine_good = [];
let wine_good_name = ['Mojito','Red_Wine','Cosmopolitan'];
let wine_good_desc = [
'Mix this classic cocktail for a party using fresh mint, white rum, sugar, zesty lime and cooling soda water. Enjoy more leisure time!',
'Red wine has a sweet, dark flavor. It has the perfect balance of sour, bitter, and sweet elements. You can enjoy it at anytime!',
'Lipsmackingly sweet and sour, the Cosmopolitan cocktail of vodka, cranberry, orange liqueur and citrus is a good-time in a glass. Perfect for relax!'];
let wine_excellent = [];
let wine_excellent_name = ['Alenander','Baileys','Pina_Colada'];
let wine_excellent_desc = [
'It is a blend of amaretto, cream, lemon curd and vanilla, finished with flowers. You can enjoy a springtime twist on a brandy alexander with Alexander cocktail!', 
'It is a creamy liqueur, made with Irish whiskey and cream. It is rich and sweet. It is able to bring much more joy to your life!',
'With rum, coconut milk and pineapple juice as the main ingredients, add ice to mix and stir, taste rich and sweet. You can have a wonderful time!'];
let wine_image_all = [wine_poor,wine_fair,wine_average,wine_good,wine_excellent];
let wine_name_all = [wine_poor_name,wine_fair_name,wine_average_name,wine_good_name,wine_excellent_name];
let wine_desc_all = [wine_poor_desc,wine_fair_desc,wine_average_desc,wine_good_desc,wine_excellent_desc];
let idx = 0;
let saveButton;
let arrow_left;
let arrow_right;
let byeTextarea;
let desc_God;



function preload(){
  ads_background = loadImage('assets/ads_background.png');
  ads_robot = loadImage('assets/ads_robot.png');
  ads_music = loadImage('assets/ads_music.png');
  page_0_img = loadImage('assets/page_0.jpg');
  page_1_robot = loadImage('assets/page_1_robot.png');
  page_2_img = loadImage('assets/page_2_img.jpg');
  circle = loadImage('assets/circle.png');
  page_3_wave = loadImage('assets/page_3_wave.png')
  page_4_light = loadImage('assets/page_4_light.png');
  wine_poor[0] = loadImage('assets/Manhattan.png');
  wine_poor[1] = loadImage('assets/Gin_Tonic.png');
  wine_poor[2] = loadImage('assets/Absinthe.png');
  wine_fair[0] = loadImage('assets/Bloody_Mary.png');
  wine_fair[1] = loadImage('assets/Tequila.png');
  wine_fair[2] = loadImage('assets/Dry_Martini.png');
  wine_average[0] = loadImage('assets/Screwdriver.png');
  wine_average[1] = loadImage('assets/Michelada.png');
  wine_average[2] = loadImage('assets/Margarita.png');
  wine_good[0] = loadImage('assets/Mojito.png');
  wine_good[1] = loadImage('assets/Red_Wine.png');
  wine_good[2] = loadImage('assets/Cosmopolitan.png');
  wine_excellent[0] = loadImage('assets/Alenander.png');
  wine_excellent[1] = loadImage('assets/Baileys.png');
  wine_excellent[2] = loadImage('assets/Pina_Colada.png');
  arrow_left = loadImage('assets/arrow_left.png');
  arrow_right = loadImage('assets/arrow_right.png');
}


/*
Code Referencing and Credit: (ChatGPT,2023)
setTimeout function is inspired by ChatGPT
Some button styles and callback are inspired by ChatGPT as well
*/
function setup(){
	createCanvas(windowWidth,windowHeight);

  imageMode(CENTER);
  ads_background.resize(width,height);
  page_0_img.resize(width,height);
  page_2_img.resize(width,height);
  
  setTimeout(function() {
    isAdOver = true;
  }, 1500);
  
  //Create Silly Buttons
  page_1_buttonA = createButton('Fly your text on the screen');
  page_1_buttonA.position(0.05*width, 0.67*height);
  page_1_buttonA.size(0.9*width,0.08*height);
  page_1_buttonA.style('border', 'none'); 
  page_1_buttonA.style('border-radius', '50px');
  page_1_buttonA.style('background-color', 'rgb(128,49,148,0.7)'); 
  page_1_buttonA.style('text-align', 'center');
  page_1_buttonA.style('color', 'rgb(230,216,243)');  
  page_1_buttonA.style('font-size', '40px');
  page_1_buttonA.mousePressed(heyPage2);
  page_1_buttonA.hide();

  page_1_buttonB = createButton('Craft your mood drink');
  page_1_buttonB.position(0.05*width, 0.8*height);
  page_1_buttonB.size(0.9*width,0.08*height);
  page_1_buttonB.style('border', 'none'); 
  page_1_buttonB.style('border-radius', '50px');
  page_1_buttonB.style('background-color', 'rgb(128,49,148,0.7)'); 
  page_1_buttonB.style('text-align', 'center'); 
  page_1_buttonB.style('padding-right', '25px');
  page_1_buttonB.style('color', 'rgb(230,216,243)');
  page_1_buttonB.style('font-size', '40px');
  page_1_buttonB.mousePressed(heyPage3);  
  page_1_buttonB.hide();

  bullet_input = createInput('');
  bullet_input.position(0.05*width, 0.6*height);
  bullet_input.size(0.9*width, 0.25*height);
  bullet_input.style('font-size', '35px');
	bullet_input.style('background-color', 'rgba(18, 37, 53)');
	bullet_input.attribute('placeholder', 'Fly your mood here...');
  bullet_input.style('border', '1px solid rgb(236, 113, 164)');
	bullet_input.style("border-radius", "50px");
  bullet_input.style('color', 'white');
  bullet_input.hide();

  page_2_button = createButton('Fly!');
  page_2_button.position(0.3*width, 0.9*height);
  page_2_button.size(0.4*width,0.05*height);
  page_2_button.style('border', 'none'); 
  page_2_button.style('border-radius', '30px'); 
  page_2_button.style('background-color', 'rgb(128,49,148)');
  page_2_button.style('color', 'white');
  page_2_button.style('font-size', '50px');
  page_2_button.mouseClicked(sendMessage);
  page_2_button.hide();

  sa_input = createElement('textarea');
  sa_input.attribute("rows","10");
  sa_input.attribute("cols","50");
  sa_input.position(0.05*width, 0.6*height);
  sa_input.size(0.9*width, 0.25*height);
  sa_input.style('font-size', '50px');
  sa_input.style('color', 'white');  
  sa_input.style('background-color', 'rgba(18, 37, 53)');
  sa_input.attribute('placeholder', 'Write your mood like I am happy here...');
  sa_input.style('border', '1px solid rgb(236, 113, 164)');
  sa_input.style("padding", "20px"); 
  sa_input.style("border-radius", "50px"); 
  sa_input.hide();

  page_3_button = createButton('Next');
  page_3_button.position(0.3*width, 0.9*height);
  page_3_button.size(0.4*width,0.05*height);
  page_3_button.style('border', 'none'); 
  page_3_button.style('border-radius', '30px'); 
  page_3_button.style('background-color', 'rgb(128,49,148)');
  page_3_button.style('color', 'rgb(230,216,243)');
  page_3_button.style('font-size', '30px');
  page_3_button.mousePressed(heyPage4); 
  page_3_button.hide();

  saveButton = createButton('Save Image');
  saveButton.position(0.3*width, 0.9*height);
  saveButton.size(0.4*width,0.05*height);
  saveButton.style('border', 'none'); 
  saveButton.style('border-radius', '30px'); 
  saveButton.style('background-color', 'rgb(76,33,115,90)');
  saveButton.mousePressed(saveImage);
  saveButton.hide();

  byeTextarea = createElement('textarea','switch and see');
  byeTextarea.attribute('cols', '25');
  byeTextarea.attribute('rows', '8');
  byeTextarea.position(0.18*width, 0.7*height);
  byeTextarea.attribute('readonly', '');
  byeTextarea.style('resize', 'none');
  byeTextarea.style('text-align', 'center');
  byeTextarea.style('background-color', 'transparent');
  byeTextarea.style('color', 'white');
  byeTextarea.style('border', 'none');
  byeTextarea.style('font-size', '40px');
  byeTextarea.style('pointer-events', 'none');
  byeTextarea.hide();
}


/*
Code Referencing and Credit: (ChatGPT,2023)
The page switch functionality is inspired by ChatGPT
*/
function draw() {
  switch (currentPage) {
    case 0: //Page 0: Ads + Introduction
        if (!isAdOver) {
          image(ads_background, width/2, height/2);
          image(ads_robot,0.1*width,height/2, 0.75*width, 0.75*width);
          image(ads_music,0.8*width,0.9*height, 0.7*width, 0.7*width);
          textSize(100);
          fill(255,70);
          text('Synthwave',0.05*width,0.18*height);
          text('Lounge',0.05*width,0.25*height);
        } else {
          image(page_0_img, width/2, height/2);
          fill(255,70);
          textSize(60);
          textAlign(CENTER,CENTER);
          text("Craft your mood",width/2,0.45*height);
          text("drink today and",width/2,height/2);
          text("enjoy the melody",width/2,0.55*height);
          textSize(30);
          fill(255);
          text("Click anywhere to start",width/2,0.9*height);
        }
      break;

      case 1: //Page 1: Slection Page
        background(9,8,28);
        image(page_1_robot, width/2, height/2, width,height);
        page_1_buttonA.show();
        page_1_buttonB.show();
        break;
        
      case 2: // Page 2: Bullet Chat Page
        page_1_buttonA.hide();
        page_1_buttonB.hide();
        page_2_furnish();
        break;
        
      case 3: // Page 3： SA Input Page
        page_1_buttonA.hide();
        page_1_buttonB.hide();
        page_3_furnish();
        break;

      case 4: // Page 4: SA Result Page
        page_3_button.hide();
        sa_input.hide();
        page_4_furnish();
        saveButton.show();
        break;
   
}}


function heyPage2(){
  currentPage = 2;
}


function page_2_furnish(){
  image(page_2_img, width/2, height/2);
  textSize(60);
  fill(255,70);
  textAlign(CENTER);
  text('Fly your text on the screen',width/2,0.08*height);
  fill(255,90);
  text("Hello",width/2, 0.35*height);
  text("你好", 0.18*width, 0.21*height);
  text("Hola",0.85*width, 0.27*height);
  textSize(25);
  text("안녕하세요", 0.05*width, 0.45*height);
  text("Bonjour", 0.3*width, 0.5*height);
  text("こんにちは",0.83*width,0.47*height);
  image(circle, width/2, 0.35*height,0.4*width,0.4*width);
  image(circle,0.18*width,0.21*height,0.24*width,0.24*width);
  image(circle,0.05*width,0.45*height,0.25*width,0.25*width);
  image(circle,0.3*width,0.5*height,0.15*width,0.15*width);
  image(circle, 0.85*width, 0.27*height,0.25*width,0.25*width);
  image(circle,0.83*width,0.47*height,0.25*width,0.25*width);
  bullet_input.show();
  page_2_button.show();
}

function heyPage3(){
  currentPage = 3;
}

function page_3_furnish(){
  background(9,8,28);
  textSize(55);
  fill(255,70);
  text('How is your day, friend?', width/2,0.1*height);
  image(page_3_wave,width/2,0.35*height,0.8*width,0.4*height);
  sa_input.show();
  page_3_button.show();
}



/*
Code Referencing and Credit: 

1. (ChatGPT,2023)
We used ChatGPT to help us look up words and do simple processing
includes()  slice()

2. (The Coding Train, 2016)
   title: Coding Challenge #44: AFINN-111 Sentiment Analysis - Part 2
   link: https://youtu.be/VV1JmMYceJw

Token Processing are inspried by The Coding Train, split(/\W/).
The Chanel helps us have a better understanding of Simple Sentiment Analysis

3. (Luke, 2023)  IDEA9101 LAB WEEK 10
AFINN-165 is from IDEA9101 LAB
map(afinn165[word],-5, 5, 0, 1) is inspired by Luke
we also reference Luke's averscore calculation

4.Others
Here we also consider sth, like adverb, we double the polarity of emotion words
e.g. if the word is happy, the mark is 3, then super happy is 6, stuff like this

5. Consideration
Dictionary based Sentiment Analysis is a huge project, especially we need to make 
our own to fit the music bar client. The time is short, so we just did some simple 
bias processing. Some bias like slang, we haven't converd yet. 
*/

function heyPage4(){
  currentPage = 4;

  scoredwords = []; 
  total_score = 0;
  let inputText = sa_input.value();
  wordsArray = inputText.split(/\W/);

  // 首先找到转折词的位置
  for (let i = 0; i < wordsArray.length; i++) {
      var word = wordsArray[i].toLowerCase();
      if (barMoodConjunctions.includes(word)) {
          // 如果找到转折词，就只保留转折词及其后面的部分
          wordsArray = wordsArray.slice(i);
          break; // 找到转折词后就结束循环
      }
  }

  for (let i=0; i< wordsArray.length; i+=1){
      var word = wordsArray[i].toLowerCase();
      if (afinn165.hasOwnProperty(word)) {
          var score = map(afinn165[word],-5, 5, 0, 1);
          // 检查前一个单词是否存在
          if(i > 0) {
              var prevWord = wordsArray[i-1].toLowerCase();

              // 第一个条件，检查前一个单词是否在barMoodAdverbs列表中
              if(barMoodAdverbs.includes(prevWord)) {
                  score *= 2; // 加倍
              }

              // 第二个条件，检查前一个单词是否是 'not' 或者 'no'
              if(barMoodNegatives.includes(prevWord)) {
                  score *= -1; // 变为相反数
              }
          }

          total_score += Number(score);
          scoredwords.push(word+': '+score);
      }
  }
  averageScore = total_score/scoredwords.length;
}

/*
Credit and Reference: ChatGPT(2023)
wine images, descriptions, and name witch are inspired by ChatGPT
*/
function page_4_furnish(){

  let image_God;
  let nameGod;

  if (averageScore <= 0.2) {
    image_God = wine_image_all[0];
    nameGod = wine_name_all[0];
    desc_God = wine_desc_all[0];
  } else if (averageScore > 0.2 && averageScore <= 0.4) {
    image_God = wine_image_all[1];
    nameGod = wine_name_all[1];
    desc_God = wine_desc_all[1];
  } else if (averageScore > 0.4 && averageScore <= 0.6) {
    image_God = wine_image_all[2];
    nameGod = wine_name_all[2];
    desc_God = wine_desc_all[2];
  } else if (averageScore > 0.6 && averageScore <= 0.8) {
    image_God = wine_image_all[3];
    nameGod = wine_name_all[3];
    desc_God = wine_desc_all[3];
  } else if (averageScore > 0.8) {
    image_God = wine_image_all[4];
    nameGod = wine_name_all[4];
    desc_God = wine_desc_all[4];
  }


  background(9,8,28);
  imageMode(CENTER);
  image(page_4_light,width/2,height/2,width,width);
  fill(255,70);
  textAlign(CENTER,CENTER);
  textSize(50);
  text('Guest of honor, your spirits today',width/2,0.1*height);
  text("are calling for a",width/2, 0.14*height);
  textSize(30);
  text('Please save the image for the front desk order.',width/2,0.97*height);
  
  fill(255);
  textSize(50);
  text(nameGod[idx], width / 2, 0.25*height);
  byeTextarea.show();
  image(arrow_left, 0.1*width, height/2,0.08*width, 0.05*height);
  image(arrow_right, 0.9*width, height/2,0.08*width, 0.05*height);
  image(image_God[idx], width / 2, height / 2, 0.5*width, 0.5*width);
}


function mousePressed(){
  if (currentPage === 0 && isAdOver === true){
    currentPage = 1;
  }

  // If click on previous arrow
  if (dist(mouseX, mouseY, 0.1*width, height/2) < 0.05*width) {
      prevImage();
  }

  // If click on next arrow
  if (dist(mouseX, mouseY, 0.9*width, height/2) < 0.05*width) {
      nextImage();
  }
}


/*
The functions below are inspired by ChatGPT(2023)
*/
function nextImage() {
  idx++;
  if (idx >= wine_poor.length) {
      idx = 0;
  }
  byeTextarea.elt.value = desc_God[idx]; // 更新 byeTextarea 的内容
}

function prevImage() {
  idx--;
  if (idx < 0) {
      idx = wine_poor.length-1;
  }
  byeTextarea.elt.value = desc_God[idx]; // 更新 byeTextarea 的内容
}


function saveImage() {
  saveCanvas('Your Win Guest', 'png');
}

/*
The functions below are  inspired by LUke (2023)
The codes below are  from IDEA9101 LAB
*/

function sendMessage() {
	let postData = JSON.stringify({ id: 1, 'message': bullet_input.value() });
	xmlHttpRequest.open("POST", HOST + '/sendMessage', false);
  xmlHttpRequest.setRequestHeader("Content-Type", "application/json");
	xmlHttpRequest.send(postData);
	bullet_input.value('');
}

function setupMqtt() {
	socket = io.connect(HOST);
}
