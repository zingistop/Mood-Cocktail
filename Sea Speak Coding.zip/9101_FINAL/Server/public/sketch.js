/*
Notice: please use Google Chrome on laptop to run server coz this is made for screenplay not for phone
*/


/*
1. Star Audio Visualiation is inspired by ChatGPT (2023)
2. Firework, Cup touch, Love these 3 triggers are inspired by ChatGPT (2023)
3. Mqtt revelant is inspired by Luke (2023) IDEA9101 LAB
4. clear() is inspired by ChatGPT (2023)
*/


//Code Referencing: (Luke,2022), some variables are from the example of IDEA9101 W5.
let cnv;
var HOST = window.location.origin;
var socket;
let xmlHttpRequest = new XMLHttpRequest();
let fruits = [];
let animationTime = 0;
let MAX_NUM_MESSAGES = 2;
let allMessages = new Array();
let phase = 0;
let zoff = 0;
var noiseMax;
let loveImg;
let loveY;
let showLoveImage = false;
let fireworks = [];
let firenumber;
let showGlasses = false;
let cup1X, cup2X, cup1Y, cup2Y;
let cup1, cup2;
let ellipseSize = 0;
let imgFade = 255;
let ellipseFade = 0;

//variables revelant to Audio Visualiation
let song;
let fft;
let stars = [];

function preload() {
  loveImg = loadImage("assets/love.png");
  cup1 = loadImage("assets/cup1.png");
  cup2 = loadImage("assets/cup2.png");
  song = loadSound('assets/miss_you.mp3');
}

/*
cnv.parent is inspried by ChatGPT (2023)
Mqtt revelant is inspried by Luke (2023) IDEA9101 LAB
*/
function setup() {
  cnv = createCanvas(windowWidth, windowHeight);
  cnv.parent('canvasContainer');  // 将画布附加到容器中
  setupMqtt();
  noiseMax = random(2);
  song.loop();
  fft = new p5.FFT();
  noStroke();
  for (let i = 0; i < 30; i++) {  // 这里的数字代表星星的数量，你可以根据你自己的需求进行修改
    stars.push({
      x: random(width),
      y: random(height * 0.2),
      r: random(255),
      g: random(255),
      b: random(255)
    });
  }
}


//Code Referencing: (Luke,2022), some parts of code are from week 4 example
function draw() {
  clear(); 

  //此处为文字显示及其属性//
  push();
  for (var i = fruits.length - 1; i >= 0; i--) {
    var msg = fruits[i];

    msg.x -= 2; // 控制弹幕移动的速度 每帧 -2

    ////如果消息完全里考屏幕，从数组中移除////
    if (msg.x + textWidth(msg.textMessage) < 0) {
      fruits.splice(i, 1);
    } else {
      textSize(40);
      fill(random(255), random(255), random(255));
      text(msg.textMessage, msg.x, msg.y);
    }
  }
  pop();

  if (showLoveImage) {
    image(loveImg,0,loveY,windowWidth,loveImg.height * (windowWidth / loveImg.width));
    loveY -= 2;
    if (loveY < -loveImg.height) {showLoveImage = false;}
  }

  updateFireworks();

  if (showGlasses) {
    if (cup1X < windowWidth / 2 - 20 || cup2X > windowWidth / 2 + 20) {
      cup1X += windowWidth / 2 / (3 * 60); // Move to center in 3 seconds
      cup2X -= windowWidth / 2 / (3 * 60); // Move to center in 3 seconds
    } else {
      // Cups have reached center, start fade out and show ellipse
      if (imgFade > 0) {
        imgFade -= 255 / (1 * 60); // Fade out in 3 seconds
      }
      if (ellipseSize < 2 * windowWidth) {
        ellipseSize += windowWidth / (1 * 60); // Grow to windowWidth in 3 seconds
        ellipseFade += 255 / (1 * 60); // Fade in in 3 seconds
      } else {
        if (ellipseFade > 0) {
          ellipseFade -= 255 / (1 * 60); // Fade out in 3 seconds
        }
      }
    }

    // Draw cups with fade
    tint(255, imgFade);
    image(cup1, cup1X, cup1Y, cup1.width / 2, cup1.height / 2);
    image(cup2, cup2X, cup2Y, cup2.width / 1.5, cup2.height / 1.5);
    noTint();

    // Draw ellipse
    noFill();
    stroke(255, ellipseFade);
    ellipse(windowWidth / 2, windowHeight / 2, ellipseSize);
  }

  let spectrum = fft.analyze();

  // 计算频谱的平均幅度
  let avgAmp = 0;
  for (let i = 0; i < spectrum.length; i++) {
    avgAmp += spectrum[i];
  }
  avgAmp /= spectrum.length;

  // 基于平均幅度绘制星星
  for (let i = 0; i < stars.length; i++) {
    let star_size = map(avgAmp, 0, 255, 0, 30);  // 增大星星的大小变化范围
    let starObj = stars[i];
    star(starObj.x, starObj.y, star_size, star_size, starObj.r, starObj.g, starObj.b);
  }
}

//Code Referencing: (Luke,2022), The addNewMessage() is from the example of IDEA9101 W5.
////关键词触发功能////
function addNewMessage(newMessage) {
  console.log("ADDING NE MSG");
  fruits.push(newMessage);

  if (newMessage.textMessage.toLowerCase().includes("happy")) {
    console.log("Happy deteced in message");
    ////在这里添加我们的特效////
    createFireworks(windowWidth / 2, windowHeight / 2, 1000); // 创建烟花特效1

    for (let Fire = 0; Fire < 8; Fire++) {
      fill(random(255), random(255), random(255));
      createFireworks(
        random(windowWidth),
        random(windowHeight),
        random(10, 500)
      ); // 创建烟花特效2
    }
  } else if (newMessage.textMessage.toLowerCase().includes("love")) {
    ////在这里添加我们的特效////
    loveY = windowHeight;
    showLoveImage = true;
  } else if (newMessage.textMessage.toLowerCase().includes("nice")) {
    ////在这里添加我们的特效////
    showGlasses = true;
    cup1X = 0;
    cup2X = windowWidth;
    cup1Y = cup2Y = windowHeight / 2;
    imgFade = 255;
    ellipseSize = 0;
    ellipseFade = 0;
  }

  ////维护 allMessages 数组的长度，确保其长度不会超过 MAX_NUM_MESSAGES 这个设定的最大消息数量////
  if (allMessages.length >= MAX_NUM_MESSAGES) {
    allMessages.shift();
  }
}

//Code Referencing: (Luke,2022), The addNewMessage() is from the example of IDEA9101 W5.
function setupMqtt() {
  socket = io.connect(HOST);
  socket.on("mqttMessage", receiveMqtt);
}

//Code Referencing: (Luke,2022), The addNewMessage() is from the example of IDEA9101 W5.
function receiveMqtt(data) {
  var topic = data[0];
  var message = data[1];
  console.log("Topic: " + topic + ", message: " + message);
  var newMessage = new ChatMessage(message);
  addNewMessage(newMessage);
}


//Code Referencing: (Luke,2022), The chatMessage class is from the example of IDEA9101 W5.
class ChatMessage {
  constructor(textMessage) {
    this.textMessage = textMessage + "";
    this.x = windowWidth + 20; // 初始位置在最右边 + 20
    this.y = random(0, windowHeight / 2);
  }
}

//// Fireworks ////
class Firework {
  constructor(x, y, col) {
    this.pos = createVector(x, y);
    this.vel = p5.Vector.random2D(); // 随机方向
    this.vel.mult(random(1, 5)); // 随机速度
    this.alpha = 255;
    this.col = col;
  }

  update() {
    this.alpha -= 2; // 消失的速度
    this.pos.add(this.vel);
  }

  show() {
    noStroke();
    fill(this.col[0], this.col[1], this.col[2], this.alpha);
    ellipse(this.pos.x, this.pos.y, 4);
  }
}

function createFireworks(x, y, firenumber) {
  // 添加烟花粒子
  let col = [random(0, 255), random(0, 255), random(0, 255)]; // 随机颜色
  for (let i = 0; i < firenumber; i++) {
    fireworks.push(new Firework(x, y, col));
  }
}

function updateFireworks() {
  for (let i = fireworks.length - 1; i >= 0; i--) {
    fireworks[i].update();
    fireworks[i].show();

    // 如果烟花完全消失，从数组中移除它
    if (fireworks[i].alpha <= 0) {
      fireworks.splice(i, 1);
    }
  }
}

function star(x, y, radius1, radius2, r, g, b) {
  beginShape();
  for (let angle = 0; angle < TWO_PI; angle += PI / 5) {
    let sx = x + cos(angle) * radius2;
    let sy = y + sin(angle) * radius2;
    vertex(sx, sy);
    sx = x + cos(angle + PI / 5) * radius1;
    sy = y + sin(angle + PI / 5) * radius1;
    vertex(sx, sy);
  }
  endShape(CLOSE);
  fill(r, g, b, 80);  // 添加透明度来使星星的颜色变化更慢
}